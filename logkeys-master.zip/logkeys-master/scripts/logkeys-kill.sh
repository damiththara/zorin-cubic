#!/bin/sh
logkeys --kill
